# ==========================================================
# LEGENDS OF ELDORIA
#
# Expert Challenge 1
#
# Dynamic Character Ranking System
#
# This solution demonstrates:
# - Object-Oriented Programming
# - The Visitor Pattern
# - Reuse of existing visitors
# - Leaderboard generation
# ==========================================================


# ==========================================================
# VISITOR INTERFACE
# ==========================================================

class Visitor:
    """
    Abstract Visitor class.

    All visitors should inherit from this class and
    implement methods for each character type.
    """

    def visit_knight(self, knight):
        pass

    def visit_archer(self, archer):
        pass

    def visit_wizard(self, wizard):
        pass

    def visit_healer(self, healer):
        pass

    def visit_rogue(self, rogue):
        pass


# ==========================================================
# CHARACTER CLASSES
# ==========================================================

class Knight:
    """
    Represents a Knight character.

    Knights specialise in heavy armour and melee combat.
    """

    def __init__(self, name, health, strength,
                 armour, years_of_service):

        self.name = name
        self.health = health
        self.strength = strength
        self.armour = armour
        self.years_of_service = years_of_service

    def __str__(self):

        return (
            "Knight(" +
            str(self.name) +
            ", Health=" +
            str(self.health) +
            ")"
        )

    def accept(self, visitor):
        return visitor.visit_knight(self)


class Archer:
    """
    Represents an Archer character.

    Archers specialise in ranged combat.
    """

    def __init__(self, name, health,
                 accuracy, agility, attack_range):

        self.name = name
        self.health = health
        self.accuracy = accuracy
        self.agility = agility
        self.attack_range = attack_range

    def __str__(self):

        return (
            "Archer(" +
            str(self.name) +
            ", Health=" +
            str(self.health) +
            ")"
        )

    def accept(self, visitor):
        return visitor.visit_archer(self)


class Wizard:
    """
    Represents a Wizard character.

    Wizards rely on intelligence, mana and spell power.
    """

    def __init__(self, name, health,
                 mana, intelligence, spell_power):

        self.name = name
        self.health = health
        self.mana = mana
        self.intelligence = intelligence
        self.spell_power = spell_power

    def __str__(self):

        return (
            "Wizard(" +
            str(self.name) +
            ", Health=" +
            str(self.health) +
            ")"
        )

    def accept(self, visitor):
        return visitor.visit_wizard(self)


class Healer:
    """
    Represents a Healer character.

    Healers support allies using restorative magic.
    """

    def __init__(self, name, health,
                 faith, healing_power, compassion):

        self.name = name
        self.health = health
        self.faith = faith
        self.healing_power = healing_power
        self.compassion = compassion

    def __str__(self):

        return (
            "Healer(" +
            str(self.name) +
            ", Health=" +
            str(self.health) +
            ")"
        )

    def accept(self, visitor):
        return visitor.visit_healer(self)


class Rogue:
    """
    Represents a Rogue character.

    Rogues specialise in stealth and agility.
    """

    def __init__(self, name, health,
                 stealth, dexterity,
                 lockpicking_skill):

        self.name = name
        self.health = health
        self.stealth = stealth
        self.dexterity = dexterity
        self.lockpicking_skill = lockpicking_skill

    def __str__(self):

        return (
            "Rogue(" +
            str(self.name) +
            ", Health=" +
            str(self.health) +
            ")"
        )

    def accept(self, visitor):
        return visitor.visit_rogue(self)


# ==========================================================
# EXISTING VISITORS
# ==========================================================

class BattleRatingVisitor(Visitor):
    """
    Calculates battle ratings.
    """

    def visit_knight(self, knight):

        return (
            knight.strength * 0.5 +
            knight.armour * 0.3 +
            knight.years_of_service * 2
        )

    def visit_archer(self, archer):

        return (
            archer.accuracy * 0.4 +
            archer.agility * 0.4 +
            archer.attack_range * 0.2
        )

    def visit_wizard(self, wizard):

        return (
            wizard.intelligence * 0.4 +
            wizard.spell_power * 0.4 +
            wizard.mana * 0.2
        )

    def visit_healer(self, healer):

        return (
            healer.healing_power * 0.5 +
            healer.faith * 0.3 +
            healer.compassion * 0.2
        )

    def visit_rogue(self, rogue):

        return (
            rogue.stealth * 0.4 +
            rogue.dexterity * 0.4 +
            rogue.lockpicking_skill * 0.2
        )


class TournamentVisitor(Visitor):
    """
    Tournament rankings defined by the Esports Team.
    """

    def visit_knight(self, knight):
        return 75

    def visit_archer(self, archer):
        return 90

    def visit_wizard(self, wizard):
        return 85

    def visit_healer(self, healer):
        return 60

    def visit_rogue(self, rogue):
        return 95


class MagicAffinityVisitor(Visitor):
    """
    Calculates magical affinity.
    """

    def visit_knight(self, knight):
        return 20

    def visit_archer(self, archer):
        return 35

    def visit_wizard(self, wizard):
        return 100

    def visit_healer(self, healer):
        return 80

    def visit_rogue(self, rogue):
        return 10


# ==========================================================
# NEW EXPERT VISITOR
# ==========================================================

class CharacterRankingVisitor(Visitor):
    """
    Produces an overall ranking score by combining:

    - Battle Rating (50%)
    - Tournament Score (30%)
    - Magic Affinity (20%)
    """

    def __init__(self):

        self.battle_visitor = BattleRatingVisitor()
        self.tournament_visitor = TournamentVisitor()
        self.magic_visitor = MagicAffinityVisitor()

    def calculate_overall_score(self, character):

        battle_score = character.accept(
            self.battle_visitor
        )

        tournament_score = character.accept(
            self.tournament_visitor
        )

        magic_score = character.accept(
            self.magic_visitor
        )

        return (
            battle_score * 0.5 +
            tournament_score * 0.3 +
            magic_score * 0.2
        )

    def visit_knight(self, knight):
        return self.calculate_overall_score(knight)

    def visit_archer(self, archer):
        return self.calculate_overall_score(archer)

    def visit_wizard(self, wizard):
        return self.calculate_overall_score(wizard)

    def visit_healer(self, healer):
        return self.calculate_overall_score(healer)

    def visit_rogue(self, rogue):
        return self.calculate_overall_score(rogue)


# ==========================================================
# MAIN PROGRAM
# ==========================================================

def main():

    # --------------------------------------------------
    # Create character objects
    # --------------------------------------------------

    sir_cedric = Knight(
        "Sir Cedric",
        100,
        85,
        90,
        12
    )

    robin = Archer(
        "Robin Oakwood",
        80,
        95,
        90,
        75
    )

    merlin = Wizard(
        "Merlin the Wise",
        60,
        120,
        100,
        95
    )

    elara = Healer(
        "Sister Elara",
        70,
        90,
        95,
        100
    )

    shadow_fox = Rogue(
        "Shadow Fox",
        75,
        95,
        90,
        85
    )

    # --------------------------------------------------
    # Store characters in a collection
    # --------------------------------------------------

    characters = [
        sir_cedric,
        robin,
        merlin,
        elara,
        shadow_fox
    ]

    # --------------------------------------------------
    # Create ranking visitor
    # --------------------------------------------------

    ranking_visitor = CharacterRankingVisitor()

    # --------------------------------------------------
    # Create leaderboard
    # --------------------------------------------------

    leaderboard = []

    for character in characters:

        score = character.accept(
            ranking_visitor
        )

        leaderboard.append(
            (character.name, score)
        )

    # --------------------------------------------------
    # Sort highest to lowest
    # --------------------------------------------------

    leaderboard.sort(
        key=lambda result: result[1],
        reverse=True
    )

    # --------------------------------------------------
    # Display leaderboard
    # --------------------------------------------------

    print("==============================")
    print("LEGENDS OF ELDORIA LEADERBOARD")
    print("==============================")

    for rank, result in enumerate(
        leaderboard,
        start=1
    ):

        print(
            str(rank) +
            ". " +
            str(result[0]) +
            " (" +
            str(round(result[1], 2)) +
            ")"
        )

    # --------------------------------------------------
    # Display strongest character
    # --------------------------------------------------

    strongest_character = leaderboard[0]

    print()
    print("Strongest Character:")

    print(
        str(strongest_character[0]) +
        " with a score of " +
        str(round(strongest_character[1], 2))
    )


# ==========================================================
# PROGRAM ENTRY POINT
# ==========================================================

if __name__ == "__main__":
    main()


# ==========================================================
# REFLECTION ANSWERS
# ==========================================================

# Q1: Would it have been easy to implement this feature
# without the Visitor Pattern?
#
# No.
# Every character class would require a new
# calculate_overall_ranking() method.
# As more scoring systems were added, the character
# classes would grow larger and become harder
# to maintain.


# Q2: How many existing classes needed modification?
#
# None.
#
# A new CharacterRankingVisitor was created.
# The existing character classes remained unchanged.


# Q3: What benefit was gained by reusing information
# from existing visitors?
#
# Existing functionality could be reused.
# We did not need to duplicate battle rating,
# tournament score or magic affinity calculations.


# Q4: Could the ranking algorithm be changed later
# without altering character classes?
#
# Yes.
#
# The weighting formula can be changed inside
# CharacterRankingVisitor without modifying:
#
# - Knight
# - Archer
# - Wizard
# - Healer
# - Rogue
#
# This improves maintainability and extensibility.


# SOFTWARE ENGINEERING CONCLUSION
#
# The Visitor Pattern allows software engineers to
# add new behaviours without repeatedly modifying
# stable classes.
#
# This supports:
#
# - Separation of Concerns
# - Maintainability
# - Extensibility
# - Open/Closed Principle