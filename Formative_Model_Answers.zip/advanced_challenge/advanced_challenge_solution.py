# ==========================================================
# LEGENDS OF ELDORIA
#
# Visitor Pattern Example
#
# This program demonstrates how new functionality can be
# added to existing character classes using the Visitor
# Pattern.
#
# Character classes remain relatively stable whilst new
# Visitors can be added whenever the game designers request
# new scoring systems.
# ==========================================================


# ==========================================================
# VISITOR INTERFACE
# ==========================================================

class Visitor:
    """
    Abstract Visitor class.

    This class defines the contract that all Visitors must
    follow. Any Visitor added to the game should implement
    methods for each character type.

    Examples:
        BattleRatingVisitor
        TournamentVisitor
        MagicAffinityVisitor
    """

    def visit_knight(self, knight):
        pass

    def visit_archer(self, archer):
        pass

    def visit_wizard(self, wizard):
        pass

    def visit_healer(self, healer):
        pass

    def visit_rogue(self, rogue):
        pass


# ==========================================================
# CONCRETE VISITORS
# ==========================================================

class BattleRatingVisitor(Visitor):
    """
    Calculates the battle rating for each character.

    The game uses battle ratings when matching characters
    to quests, tournaments and battles.
    """

    def visit_knight(self, knight):

        # Battle score based on combat statistics
        return (
            knight.strength * 0.5 +
            knight.armour * 0.3 +
            knight.years_of_service * 2
        )

    def visit_archer(self, archer):

        return (
            archer.accuracy * 0.4 +
            archer.agility * 0.4 +
            archer.attack_range * 0.2
        )

    def visit_wizard(self, wizard):

        return (
            wizard.intelligence * 0.4 +
            wizard.spell_power * 0.4 +
            wizard.mana * 0.2
        )

    def visit_healer(self, healer):

        return (
            healer.healing_power * 0.5 +
            healer.faith * 0.3 +
            healer.compassion * 0.2
        )

    def visit_rogue(self, rogue):

        return (
            rogue.stealth * 0.4 +
            rogue.dexterity * 0.4 +
            rogue.lockpicking_skill * 0.2
        )


class TournamentVisitor(Visitor):
    """
    Calculates tournament scores.

    The Esports Team uses these values when generating
    player rankings.
    """

    def visit_knight(self, knight):
        return 75

    def visit_archer(self, archer):
        return 90

    def visit_wizard(self, wizard):
        return 85

    def visit_healer(self, healer):
        return 60

    def visit_rogue(self, rogue):
        return 95


class MagicAffinityVisitor(Visitor):
    """
    Calculates magical affinity.

    Used by the balancing team when determining which
    characters have the strongest connection to magic.
    """

    def visit_knight(self, knight):
        return 20

    def visit_archer(self, archer):
        return 35

    def visit_wizard(self, wizard):
        return 100

    def visit_healer(self, healer):
        return 80

    def visit_rogue(self, rogue):
        return 10


# ==========================================================
# CHARACTER CLASSES
# ==========================================================

class Knight:
    """
    Represents a Knight character.

    Knights are heavily armoured melee fighters that
    specialise in defence and close combat.
    """

    def __init__(self, name, health, strength,
                 armour, years_of_service):

        self.name = name
        self.health = health
        self.strength = strength
        self.armour = armour
        self.years_of_service = years_of_service

    def __str__(self):
        """
        Returns a readable string representation
        of the Knight object.
        """

        return (
            f"Knight({self.name}, "
            f"Health={self.health})"
        )

    def shield_wall(self):
        """
        Knight's special ability.
        """

        return f"{self.name} raises a shield wall!"

    def accept(self, visitor):
        """
        Accept a Visitor.

        The Visitor Pattern works by passing a Visitor
        object into this method.

        Rather than the Knight class carrying out the
        calculation itself, the Visitor performs the
        operation.

        Example:
            knight.accept(visitor)

        becomes:

            visitor.visit_knight(knight)
        """

        return visitor.visit_knight(self)


class Archer:
    """
    Represents an Archer character.

    Archers rely on range, agility and accuracy to
    defeat their opponents.
    """

    def __init__(self, name, health,
                 accuracy, agility, attack_range):

        self.name = name
        self.health = health
        self.accuracy = accuracy
        self.agility = agility
        self.attack_range = attack_range

    def __str__(self):

        return (
            f"Archer({self.name}, "
            f"Health={self.health})"
        )

    def rapid_shot(self):
        """
        Archer's special ability.
        """

        return f"{self.name} fires a rapid volley!"

    def accept(self, visitor):

        # Delegate behaviour to the Visitor
        return visitor.visit_archer(self)


class Wizard:
    """
    Represents a Wizard character.

    Wizards specialise in magical attacks and possess
    high intelligence and spell power.
    """

    def __init__(self, name, health,
                 mana, intelligence, spell_power):

        self.name = name
        self.health = health
        self.mana = mana
        self.intelligence = intelligence
        self.spell_power = spell_power

    def __str__(self):

        return (
            f"Wizard({self.name}, "
            f"Health={self.health})"
        )

    def cast_spell(self):
        """
        Wizard's special ability.
        """

        return f"{self.name} casts Arcane Blast!"

    def accept(self, visitor):

        return visitor.visit_wizard(self)


class Healer:
    """
    Represents a Healer character.

    Healers support allies through restorative magic
    and healing abilities.
    """

    def __init__(self, name, health,
                 faith, healing_power, compassion):

        self.name = name
        self.health = health
        self.faith = faith
        self.healing_power = healing_power
        self.compassion = compassion

    def __str__(self):

        return (
            f"Healer({self.name}, "
            f"Health={self.health})"
        )

    def heal(self):
        """
        Healer's special ability.
        """

        return f"{self.name} restores health!"

    def accept(self, visitor):

        return visitor.visit_healer(self)


class Rogue:
    """
    Represents a Rogue character.

    Rogues specialise in stealth, infiltration and
    critical strikes.
    """

    def __init__(self, name, health,
                 stealth, dexterity, lockpicking_skill):

        self.name = name
        self.health = health
        self.stealth = stealth
        self.dexterity = dexterity
        self.lockpicking_skill = lockpicking_skill

    def __str__(self):

        return (
            f"Rogue({self.name}, "
            f"Health={self.health})"
        )

    def stealth_attack(self):
        """
        Rogue's special ability.
        """

        return f"{self.name} performs a stealth attack!"

    def accept(self, visitor):

        return visitor.visit_rogue(self)


# ==========================================================
# MAIN PROGRAM
# ==========================================================

def main():
    """
    Create character objects and apply Visitors.

    This demonstrates that the same character can
    receive multiple operations simply by changing
    the Visitor.
    """

    # ------------------------------------------
    # Create Characters
    # ------------------------------------------

    sir_cedric = Knight(
        "Sir Cedric",
        100,
        85,
        90,
        12
    )

    robin = Archer(
        "Robin Oakwood",
        80,
        95,
        90,
        75
    )

    merlin = Wizard(
        "Merlin the Wise",
        60,
        120,
        100,
        95
    )

    elara = Healer(
        "Sister Elara",
        70,
        90,
        95,
        100
    )

    shadow_fox = Rogue(
        "Shadow Fox",
        75,
        95,
        90,
        85
    )

    # Store all characters in a single collection

    characters = [
        sir_cedric,
        robin,
        merlin,
        elara,
        shadow_fox
    ]

    # ------------------------------------------
    # Create Visitors
    # ------------------------------------------

    battle_visitor = BattleRatingVisitor()
    tournament_visitor = TournamentVisitor()
    magic_visitor = MagicAffinityVisitor()

    # ------------------------------------------
    # Apply Visitors
    # ------------------------------------------

    print("=== CHARACTER ANALYSIS ===")

    for character in characters:

        print("\n" + character.name)

        # Character passes control to Visitor
        print(
            "Battle Rating:",
            round(character.accept(battle_visitor), 2)
        )

        print(
            "Tournament Score:",
            character.accept(tournament_visitor)
        )

        print(
            "Magic Affinity:",
            character.accept(magic_visitor)
        )

    # ------------------------------------------
    # Find highest tournament score
    # ------------------------------------------

    top_tournament_character = max(
        characters,
        key=lambda character:
            character.accept(tournament_visitor)
    )

    print("\nHighest Tournament Score:")
    print(top_tournament_character.name)

    # ------------------------------------------
    # Find highest magic affinity
    # ------------------------------------------

    top_magic_character = max(
        characters,
        key=lambda character:
            character.accept(magic_visitor)
    )

    print("\nHighest Magic Affinity:")
    print(top_magic_character.name)


if __name__ == "__main__":
    main()


# ==========================================================
# REFLECTION ANSWERS
# ==========================================================

# What problem does the Visitor Pattern solve?
#
# It separates operations from the character classes.
#
# New functionality can be added without modifying
# Knight, Archer, Wizard, Healer or Rogue.


# What remains relatively stable?
#
# The character hierarchy:
#
# Knight
# Archer
# Wizard
# Healer
# Rogue


# What changes frequently?
#
# Battle Ratings
# Tournament Scores
# Magic Affinity Scores
# Leaderboards
# Future game calculations


# How does Visitor improve maintainability?
#
# Each calculation has its own Visitor class.
# Related logic is grouped together.


# How does Visitor support Open/Closed Principle?
#
# Open for extension:
#     Create a new Visitor.
#
# Closed for modification:
#     Existing character classes remain unchanged.


# Dragon Rider Discussion
#
# Adding DragonRider requires:
#
# visit_dragon_rider()
#
# to be added to every Visitor.
#
# This demonstrates the major trade-off
# of the Visitor Pattern:
#
# Easy to add new operations.
# Harder to add new character types.