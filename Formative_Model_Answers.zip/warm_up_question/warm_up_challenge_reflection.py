# Reflection Question 1
# Why classes rather than dictionaries?
#
# Classes combine both data and behaviour.
# They improve organisation, readability and maintainability.

# Reflection Question 2
# Common attributes?
#
# Name
# Health

# Reflection Question 3
# Could a parent Character class reduce duplication?
#
# Yes. Name and Health appear in every class.
# Common behaviours could also be inherited.

# Reflection Question 4
# Where would Battle Rating functionality be added?
#
# At this stage it would likely be added directly to each class,
# although this may eventually become difficult to maintain.