class Knight:
    """Represents a Knight character in Legends of Eldoria."""

    def __init__(self, name, health, strength, armour, years_of_service):
        self.name = name
        self.health = health
        self.strength = strength
        self.armour = armour
        self.years_of_service = years_of_service

    def __str__(self):
        return (
            f"Knight(Name={self.name}, "
            f"Health={self.health}, "
            f"Strength={self.strength}, "
            f"Armour={self.armour}, "
            f"Years of Service={self.years_of_service})"
        )

    def shield_wall(self):
        return f"{self.name} raises a shield wall!"

    def calculate_battle_rating(self):
        return (
            self.strength * 0.5 +
            self.armour * 0.3 +
            self.years_of_service * 2
        )


class Archer:
    """Represents an Archer character in Legends of Eldoria."""

    def __init__(self, name, health, accuracy, agility, attack_range):
        self.name = name
        self.health = health
        self.accuracy = accuracy
        self.agility = agility
        self.attack_range = attack_range

    def __str__(self):
        return (
            f"Archer(Name={self.name}, "
            f"Health={self.health}, "
            f"Accuracy={self.accuracy}, "
            f"Agility={self.agility}, "
            f"Range={self.attack_range})"
        )

    def rapid_shot(self):
        return f"{self.name} unleashes a rapid volley!"

    def calculate_battle_rating(self):
        return (
            self.accuracy * 0.4 +
            self.agility * 0.4 +
            self.attack_range * 0.2
        )


class Wizard:
    """Represents a Wizard character in Legends of Eldoria."""

    def __init__(self, name, health, mana, intelligence, spell_power):
        self.name = name
        self.health = health
        self.mana = mana
        self.intelligence = intelligence
        self.spell_power = spell_power

    def __str__(self):
        return (
            f"Wizard(Name={self.name}, "
            f"Health={self.health}, "
            f"Mana={self.mana}, "
            f"Intelligence={self.intelligence}, "
            f"Spell Power={self.spell_power})"
        )

    def cast_spell(self):
        return f"{self.name} casts Arcane Blast!"

    def calculate_battle_rating(self):
        return (
            self.intelligence * 0.4 +
            self.spell_power * 0.4 +
            self.mana * 0.2
        )


class Healer:
    """Represents a Healer character in Legends of Eldoria."""

    def __init__(self, name, health, faith, healing_power, compassion):
        self.name = name
        self.health = health
        self.faith = faith
        self.healing_power = healing_power
        self.compassion = compassion

    def __str__(self):
        return (
            f"Healer(Name={self.name}, "
            f"Health={self.health}, "
            f"Faith={self.faith}, "
            f"Healing Power={self.healing_power}, "
            f"Compassion={self.compassion})"
        )

    def heal(self):
        return f"{self.name} restores health to allies!"

    def calculate_battle_rating(self):
        return (
            self.healing_power * 0.5 +
            self.faith * 0.3 +
            self.compassion * 0.2
        )


class Rogue:
    """Represents a Rogue character in Legends of Eldoria."""

    def __init__(self, name, health, stealth, dexterity, lockpicking_skill):
        self.name = name
        self.health = health
        self.stealth = stealth
        self.dexterity = dexterity
        self.lockpicking_skill = lockpicking_skill

    def __str__(self):
        return (
            f"Rogue(Name={self.name}, "
            f"Health={self.health}, "
            f"Stealth={self.stealth}, "
            f"Dexterity={self.dexterity}, "
            f"Lockpicking={self.lockpicking_skill})"
        )

    def stealth_attack(self):
        return f"{self.name} performs a stealth attack!"

    def calculate_battle_rating(self):
        return (
            self.stealth * 0.4 +
            self.dexterity * 0.4 +
            self.lockpicking_skill * 0.2
        )


def main():

    sir_cedric = Knight(
        "Sir Cedric",
        100,
        85,
        90,
        12
    )

    robin = Archer(
        "Robin Oakwood",
        80,
        95,
        90,
        75
    )

    merlin = Wizard(
        "Merlin the Wise",
        60,
        120,
        100,
        95
    )

    elara = Healer(
        "Sister Elara",
        70,
        90,
        95,
        100
    )

    shadow_fox = Rogue(
        "Shadow Fox",
        75,
        95,
        90,
        85
    )

    party = [
        sir_cedric,
        robin,
        merlin,
        elara,
        shadow_fox
    ]

    print("=== PARTY MEMBERS ===")

    for character in party:
        print(character)

    print("\n=== SPECIAL ABILITIES ===")

    print(sir_cedric.shield_wall())
    print(robin.rapid_shot())
    print(merlin.cast_spell())
    print(elara.heal())
    print(shadow_fox.stealth_attack())

    print("\n=== BATTLE RATINGS ===")

    for character in party:
        print(
            character.name,
            round(character.calculate_battle_rating(), 2)
        )


if __name__ == "__main__":
    main()